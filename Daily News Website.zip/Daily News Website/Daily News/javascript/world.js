var information = [
    {
        title: "Spurs can't afford more injuries says Conte ahead of Milan last 16 tie",
        image1:  "images/Spurs.avif",
        image2:  "images/Spurs.avif",
        image3:  "images/Spurs.avif",
        paragraph1:"MILAN, Italy : Tottenham Hotspur will be in trouble if they pick up any more injuries, coach Antonio Conte said on the eve of their Champions League last-16 first-leg tie against AC Milan.<br> Conte, who returned to the touchline in Spurs' defeat at Leicester City on Saturday after recovering from gallbladder surgery, takes his injury-hit team to the San Siro on Tuesday <br><br> 'Playing Premier League and Champions League and also FA Cup will be really difficult, he told a news conference.' <br><br> 'At the same time we have to avoid another injury. Otherwise we will be in trouble,' the Italian added.<br><br>Spurs have lost captain and goalkeeper Hugo Lloris to a knee ligament injury that will keep him out for at least six weeks.<br> Midfielders Ryan Sessegnon, with a hamstring problem, Rodrigo Bentancur, who tore knee ligaments after scoring in the 4-1 defeat at Leicester, and Yves Bissouma, following surgery on Friday for a stress fracture in his left ankle, are all out.<br><br>'In the last seven days we have had four serious injuries. For this season I think staying together is very important and trying in this kind of situation to create the right spirit,' Conte said.",
        paragraph2:"The 53 year old, who was himself sidelined after being diagnosed with cholecystitis and having an operation to remove his gallbladder, said the situation was tough but he was looking for a solution 'at home' for his lineup away to Milan.<br><br>'We're talking about two young players, Skippy (Oliver Skipp) and Pape Sarr. (It's) their first game in the Champions League, they are very young, 22 and 20 years old,' Conte said.<br><br> 'Especially for this reason we have to be good to help them overcome the emotion, and then we trust them.'<br> Milan ended a seven-game winless run in all competitions with a 1-0 home victory over Torino on Friday and coach Stefano Pioli hopes the Champions League will lift his side.<br><br> 'It's inevitable we suffered those negative results and the victory over Torino boosted our morale,' he said on Milan TV. 'Aside from that, when the Champions League comes along, it's the Champions League. It doesn't matter what form you're in.'<br><br> 'If we're playing at this level, it means that we are strong and so are Tottenham, so we must try to do better starting from tomorrow night.'",
        alt: "image of Spurs",
    },

    {
        title: "Gakpo off the mark as Liverpool down Everton 2 to 0",
        image1:  "images/Liverpool.avif",
        image2: "images/Liverpool-2.avif",
        image3:  "images/Liverpool-3.avif",
        paragraph1:"LIVERPOOL, England :Liverpool's Cody Gakpo scored his first goal for the club as they halted a dismal run by beating relegation-threatened city rivals Everton 2-0 at Anfield in the Premier League on Monday.<br> Mohamed Salah opened the scoring in the 36th minute, linking up with Darwin Nunez on the counter-attack just after Everton missed a glorious double chance to take the lead, with Dwight McNeil going close and James Tarkowski hitting the post. <br> Netherlands forward Gakpo extended the lead early in the second half of a typically fast-paced Merseyside derby for his first goal in his seventh match for Liverpool since joining from PSV Eindhoven for a reported 37 million pounds ($44.91 million).<br> Liverpool started the game having lost three of their last four league matches while conceding nine goals and scoring one, while Everton were hopeful of turning a corner under new manager Sean Dyche after a shock win over leaders Arsenal last time out.<br> But Juergen Klopp's Liverpool side were stronger and sharper than their neighbours and earned their first league victory of 2023 to climb to ninth in the table on 32 points after 21 games.<br>Everton were left in 18th place on 18 points from 22 matches, one point off the safety zone.<br>'It's a huge win for us,' said Salah. 'We had a perfect week to train and the players were so excited and we couldn't wait for the game to turn everything around and hopefully it was a start.'",
        paragraph2:"'I know that Darwin is really fast so they had a corner and we played a one-two. I knew that he was going to play the ball in the space so I was running as fast as I could and scored so that's the most important thing.'<br> GLIMMER OF HOPE<br>Liverpool may be having a torrid season by their own high standards, having missed out on the league title to Manchester City on the final day of last season, but they still have a glimmer of hope that they can qualify for the Champions League.<br>They trail Newcastle United in fourth by nine points and have a game in hand on Eddie Howe's side, while Gakpo's confidence should be lifted after getting his first goal.<br>Salah, who was joint-top scorer in the Premier League last season, will also be relieved to have got his first league goal since netting against Aston Villa on Dec. 26.<br> Klopp was boosted by the return of striker Diogo Jota, who made his first appearance since injuring his calf in October when he came on in the 70th minute.<br>Influential defender Virgil van Dijk, meanwhile, was on the bench after injuring his hamstring at the start of January.<br>Liverpool's struggles this season pale in comparison to those of Everton, who last month sacked Frank Lampard, the seventh manager to be fired by owner Farhad Moshiri since 2017.<br>'We gave away two goals on the counter and that is massively disappointing,' said Everton defender Conor Coady.<br> 'It's important we keep listening to the manager each day and we need to go again. It's not the fact that we missed the chances, we hit the post, but giving away counters, which is what they're good at, we need to look at ourselves and see where we can put it right.'",
        alt: "image of Liverpool",
    },

    {
        title: "Once home to civilisations, fabled Antioch left in ruins after Türkiye Syria earthquake",
        image1:  "images/Turkiye.avif",
        image2:  "images/Turkiye.avif",
        image3: "images/Turkiye.avif",
        paragraph1:"ANTAKYA, Türkiye: The smashed dome of the ancient mosque, considered to be Türkiye's oldest, covers rubble that used to be a prayer hall.<br><br>Once a home to a myriad of civilisations, the southern city of Antakya lies in ruins after last Monday's 7.8-magnitude quake.<br><br>Fourteen centuries of history were ravaged in less than two minutes in Antakya, a fabled ancient Greek centre known throughout most of its history as Antioch.<br><br>Erected in the year 638, the Habib-i Neccar was 'the first mosque built within modern-day Türkiye's borders', according to the government's culture portal.<br><br> Only its walls have survived, leaving delicate yellow, red and blue paintings and calligraphy exposed to the winter sky.<br><br> 'A bit of the Prophet Muhammad's beard was once preserved in a box at the mosque', said Havva Pamukcu, a 50-year-old woman wearing a headscarf.<br><br> 'I'm heartbroken,' she said.<br><br> A few hundred metres away, a Greek Orthodox church erected in the 14th century - and rebuilt in 1870 after another earthquake - is also gone.<br><br>A white cross that once stood on its pointed roof now lies atop shattered walls and broken pieces of wood.<br><br>'All the walls have fallen. We're in despair', said Sertac Paul Bozkurt, a member of the council managing the church.",
        paragraph2:"Antakya is in Hatay, a province tucked between the Mediterranean Sea and Türkiye's border with Syria. <br><br> It was one of the worst affected by the earthquake and its aftershocks, which have claimed more than 35,000 lives across the region. <br><br> In the old city, several streets are still inaccessible, blocked by buildings flattened like pancakes and cars trapped under the debris.<br><br> Across more than two millennia, the city was home to Greek, Roman, Byzantine, Persian, Arab and Ottoman empires.<br><br> It was even placed under a French mandate between the end of World War I and 1939, when the city became a part of modern-day Türkiye.<br><br>A former general of Alexander the Great founded Antioch in 300BC.<br><br> The city has suffered several earthquakes - almost one every 100 years - and is no stranger to rebuilding.<br><br> There were devastating quakes in 37BC, 115AD and 458AD.<br><br>A quake in 526AD is thought to have killed 250,000 people. In 1054, 10,000 are thought to have died.<br><br>'Antakya is the cradle of several historical events', said Hakan Mertkan, a doctoral student at the University of Bayreuth in Germany and author of a book on Antakya.<br><br>But it is also 'a cradle of earthquakes, its soil full of history', he added.",
        alt: "image of Turkiye",
    },

    {
        title: "At least 4 dead, including gunman, in shooting at Michigan State University",
        image1:  "images/michigan-1.jpg",
        image2:  "images/michigan-2.jpg",
        image3:  "images/michigan.jpg",
        paragraph1:"LOS ANGELES - A gunman killed three people and wounded at least five others on the Michigan State University (MSU) campus in East Lansing, Michigan, on Monday night, sending students fleeing while he evaded swarms of law enforcement officers before apparently taking his own life off campus.<br><br>The gunman, whose name was not immediately released, was reported dead just after midnight on Tuesday, about four hours after the first 911 calls were made of shots fired.<br><br> Some of the five people who were wounded had life-threatening injuries, according to Mr Chris Rozman, the university Police Department's interim deputy police chief. None of the names of the victims were released.<br><br> 'We are relieved to no longer have an active threat on campus while we realise there is so much healing that will need to take place,' Mr Rozman said.<br><br>He said it was unclear what the shooter's connection was to the university or what the motive had been for the attack.<br><br>Shots were reported on campus after 8 pm, prompting the university's Police Department to send an alert urging people on campus to “secure in place immediately.”<br><br>Hundreds of law enforcement officers sped through the unusually empty streets near campus as students barricaded themselves in dorm rooms.<br><br> Mr Rozman said shots were fired inside Berkey Hall, home to the school's college of arts and sciences. He said a second shooting, “immediately following the first incident”, took place at the MSU student union.",
        paragraph2:"Mr Carson Coleman, 20, a university sophomore studying criminal justice, said he was at work as a cook at a restaurant on the edge of campus when he and others received a blast of e-mails warning of an active shooter.<br><br> “My kitchen manager, she was trying to calm us down,” he said, “but at the same time you could tell she was really freaking out.”<br><br>Mr Julian Alonso, a freshman, left his dorm to buy a snack at a nearby 7-Eleven. As he turned back toward his dorm, he saw at least 10 police vehicles.<br><br>“I covered the door with my roommate's bed and I turned off the lights,” Mr Alonso said. “I'm keeping myself hidden in the closet.”<br><br>Albert Street near campus, usually busy with bar patrons, was all but silent except for the sounds of sirens and a helicopter in the distance.<br><br>Hours after the first alert of shots fired, several campus buildings were cleared and secured, as officers swept the campus in search of a single suspect.<br><br>Students, faculty and residents in surrounding off-campus neighbourhoods of East Lansing, about 140km north-west of Detroit, were urged by the authorities to “shelter in place”, while the manhunt continued.<br><br>The suspect, initially described as a short male wearing a mask, was last seen alive fleeing the building housing the MSU student union on foot.<br><br>MSU is a major public institution of higher education whose flagship East Lansing campus accounts for 50,000 graduate and undergraduate students.<br><br>University police said on Monday night that all classes and campus activities would be cancelled for the next 48 hours.<br><br>Monday night's violence came roughly 14 months after a deadly mass shooting on Nov 30, 2021, at Oxford High School in Oakland County, Michigan, about 130km east of East Lansing, in which a 15-year-old student opened fire with a semi-automatic pistol.<br><br>Four classmates were killed and six other students and a teacher were wounded in that attack, the deadliest US school shooting that year.<br><br>The authorities said the teenage suspect, who has pleaded not guilty to murder charges, used a gun his parents bought him as a Christmas present despite signs that he was emotionally disturbed. Both parents were charged with involuntary manslaughter in the case.<br><br>Governor Gretchen Whitmer said on Twitter that she was being briefed on the East Lansing shooting. NYTIMES, REUTERS",
        alt: "image of Michigan University",
    },

    {
        title: "Sydney swelters through autumn heatwave, bushfire threat looms",
        image1:  "images/sydney.avif",
        image2:   "images/sydney.avif",
        image3:  "images/sydney.avif",
        paragraph1:"SYDNEY: Parts of Australia's east including Sydney recorded their hottest day in more than two years on Monday (Mar 6) with temperatures hitting more than 40 degrees Celsius, raising the risk of bushfires. <br> Firefighters are working to contain nearly 40 bushfires across New South Wales, the home state of one-third of Australians, with crews on the ground supported by aircraft. <br> One fire near Mudgee, more than 250km northwest of Sydney, is at emergency warning level. Emergency crews urged residents there to seek shelter as it was too late to leave.<br> Total fire bans are now in place for multiple regions across most of New South Wales, while 35 public schools, mostly in inland regions, have been closed due to the severe heat.<br> 'If a fire does start, it's going to be burning under those difficult conditions ... (it's) harder for our firefighters to get around them, and fire can spread very quickly, particularly in grassland', Angela Burford, operational officer at the New South Wales Rural Fire Service, told the Australian Broadcasting Corp.",
        paragraph2:"Dry thunderstorms are also possible across eastern New South Wales, leading to conditions that could see lightning ignite new fires, the Bureau of Meteorology said. The hot and dry conditions are likely to persist until Wednesday.<br>Penrith, a suburb in western Sydney, recorded 40.1 degrees Celsius on Monday afternoon - the hottest day since Jan 26, 2021 - while some inland towns reached nearly 41 degrees.<br>Australia's east coast has been dominated by the La Nina weather phenomenon - typically associated with increased rainfall - over the last two years, which brought record rains and widespread flooding. In 2022, Sydney recorded its highest annual rainfall since records began in 1858.<br>But the weather bureau last week said its climate models suggest La Nina was 'likely near its end' and neutral conditions, which is neither La Nina or its opposite El Nino, were likely to prevail through the southern hemisphere autumn.",
        alt: "image of Sydney",
    },

    {
        title: "Lethal Liverpool smash Manchester United for seven in record win",
        image1:  "images/Liv-Man.avif",
        image2:   "images/Liv-Man-2.avif",
        image3:  "images/Liv-Man-3.avif",
        paragraph1:"LIVERPOOL: Liverpool brought Manchester United's bandwagon to a shuddering halt as Cody Gakpo, Darwin Nunez and Mohamed Salah all scored twice in a record 7 to 0 hammering of their arch rivals to boost their Premier League top-four hopes at Anfield on Sunday (Mar 5).<br>A week after a resurgent United claimed their first trophy since 2017 by winning the League Cup and amid talk of a late title push they were blown away either side of halftime as Liverpool recorded their biggest victory in the fixture.<br>Third-placed United had looked marginally the better side for 43 minutes but it turned into an Anfield horror show for Erik ten Hag's side as they suffered the club's worst defeat since a 7-0 loss to Wolverhampton Wanderers in 1931.<br>Gakpo's superb finish from Liverpool's first attempt on target gave the hosts the halftime lead.<br>Within five minutes of the restart it was over as a contest with Nunez's header making it 2-0 after some comical defending allowed Harvey Elliott to cross and a lightning counter-attack led by Salah ended with Gakpo finishing in style for 3-0.<br>With United in disarray and losing their heads, Salah got in on the act to rifle in Liverpool's fourth in the 66th minute and Nunez then sent another header past helpless goalkeeper David De Gea in the 75th. But there was still more to come.<br>Salah rubbed salt into United wounds with a close-range effort to score a record 129th Premier League goal for the Merseyside club, taking him past the mark of Robbie Fowler.<br>Roberto Firmino then came off the bench to send Juergen Klopp's side into seventh heaven with an angled shot after more good work by Egyptian Salah, although by that stage most of United's army of followers had headed for the exits.",
        paragraph2:"It was the first time since 1999 that three players had scored two goals for the same club in the Premier League  the last time being when Andy Cole, Ole Gunnar Solskjaer and Dwight Yorke all scored twice for United against Nottingham Forest.<br>Liverpool had thrashed United 4 to 0 at Anfield last April but considering the reversal of fortunes for the two clubs since, with United on the rise and Liverpool off the pace, this result was a major surprise.<br>United's sobering defeat, described by Sky Sports pundit and their former defender Gary Neville as a 'disgrace', left them in third place on 49 points and surely out of the title race. They are 14 points off leaders Arsenal, who have played a game more.<br>Liverpool's fourth win in five league matches lifted them above Newcastle United into fifth on 42 points, three points behind fourth-placed Tottenham Hotspur with a game in hand.<br>'It was a fantastic day for everyone,' Liverpool skipper Jordan Henderson told Sky Sports. 'The performance level from every single player was top quality today which is something that we've been missing for a while of course.'<br>'oday you could see the energy levels and everything was back, although to be fair the last few Premier League games had shown we were on the right path.'<br>Liverpool's previous biggest win over United was a 7-1 victory in 1895 when both clubs were in the second tier.<br>There was no hint of what was to come in the opening period as United weathered some early pressure and engineered the better chances with Bruno Fernandes a whisker away from scoring with a header and Marcus Rashford then spurning a chance.<br>But everything changed once Gakpo was released by a superb pass from Andy Robertson down the left channel and stepped inside United midfielder Fred before dispatching a low shot inside the far post.<br>After that United's disintegration was spectacular as they suffered only their second defeat in the last 12 league games.<br>'In the second half it was just not us. It was not our standards. We didn't play as a team,'Ten Hag said.<br>'We didn't stick to the plan and we didn't do our jobs. I'm really disappointed and angry about it.'",
        alt: "image of Liverpool vs Manchester United",
    },



    
];

function loadContent(type){

    const full_view_content = document.getElementById('full_view_content');
    article_placeholder.classList.add('visible')

    for(var i = 0; i < information.length; i++){

        if(type == i){
            full_view_content.innerHTML = `
            
        <div class = "col-12 text-center">
            
            <div class = "col-2"><p></p></div>
            <div class = "col-8 text-center">
                
            </div>
           
        </div>
            
        <div class="container text-center">
            <br>
            <h1>${information[i].title}</h1>
            <br>
           
                <div class = "container text-center">
                    <div class = "row">
                        <div class = "col-md-2"></div>
                        <div class = "col-md-8">
                            <div id="carouselExampleIndicators" class="carousel slide" style="width: 100%;">
                                <div class="carousel-indicators">
                                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                                </div>
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        <img src = ${information[i].image1} alt = ${information[i].alt} height = 500px class="e-block w-80" >
                                    </div>
                                    <div class="carousel-item">
                                        <img src=${information[i].image2}  alt = ${information[i].alt} height = 500px class="e-block w-80" >
                                    </div>
                                    <div class="carousel-item">
                                        <img src=${information[i].image3} alt = ${information[i].alt} height = 500px class="e-block w-80" >
                                    </div>
                                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                                        <span class="carousel-control-prev-icon" style="color:black;" aria-hidden="true"></span>
                                        <span class="visually-hidden">Previous</span>
                                    </button>
                                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                                        <span class="carousel-control-next-icon" style="color:black;" aria-hidden="true"></span>
                                        <span class="visually-hidden">Next</span>
                                    </button>
                                </div>
                            
                            </div>
                        </div>
                        <div class = "col-md-2"></div>
                        
                    </div>
                </div>
            
            <div class = "main">
                <br>
                <div class = "row">
                    <div class="col-md-2">
                    </div>
                    <div class="col-md-8" style = "text-align: left;">
                        <p>${information[i].paragraph1}</p>
                    </div>
                    <div class = "col-md-2">
                        <a href = "#"><img src = "images/adobe-ad.gif" alt = "adobe advertisment" height="400px"></a>

                    </div>
                </div>
                <div class = "row">
                    <div class = "col-md-2">
                        <a href = "#"><img src = "images/prism-advertisment.png" alt = "prism advertisment" height="400px"></a>

                    </div>
                    <div class = "col-md-8" style = "text-align: left;"> 
                        <p>${information[i].paragraph2}</p>
                    </div>
                    <div class = "col-md-2">

                    </div>
                </div>
                
                
                <br>
                <br>
                <div class = "container text-left">
                    <div class = "row">
                        <div class = "col-md-2">
                        </div>
                        <div class = "col-md-7">
                            <h3>Related:</h3>
                        </div>
                        <div class = "col-md-3">
                        </div>
                    </div>
                    <div class = "row">
                        <div class = "col-md-2">
                        </div>
                        <div class = "col-md-9">
                            <h2 class = "line-divider"></h2>
                        </div>
                        <div class = "col-md-1">
                        </div>
                    </div>
                    
                    <div class = "row mb-3" style = "text-align: left;">
                        <div class = "col-md-2">
                        </div>
                        <div class ="col-xs-12 col-sm-12 col-md-4 col-xxl-2">
                            <a href="singapore-mask.html"><img src = "images/Singapore Mask.png" alt = "image of Singaporeans" height = 120px></a>
                        </div>
                        <div class = "col-xs-12 col-sm-12 col-md-5 col-xxl-7">
                            <br>
                            <h5><a class="nav-link" href = "#">No masks on public transport, free vaccines: 6 things you need to know as S'pore lifts Covid 19 rules </a></h5>
                        </div>
                        <div class = "col-md-2">
                        </div>
                    </div>
                    <div class = "row">
                        <div class = "col-md-2">
                        </div>
                        <div class = "col-md-9">
                            <h2 class = "line-divider"></h2>
                        </div>
                        <div class = "col-md-1">
                        </div>
                    </div>
                    <div class = "row mb-3" style = "text-align: left;">
                        <div class = "col-md-2">
                        </div>
                        <div class = "col-xs-12 col-sm-12 col-md-4 col-xxl-2">
                            <a href="singapore-mask.html"><img src = "images/Singapore Mask.png" alt = "image of Singaporeans" height = 120px></a>
                        </div>
                        <div class = "col-xs-12 col-sm-12 col-md-5 col-xxl-7">
                            <br>
                            <h5><a class="nav-link" href = "#">No masks on public transport, free vaccines: 6 things you need to know as S'pore lifts Covid 19 rules </a></h5>
                        </div>
                        <div class = "col-md-2">
                        </div>
                    </div>
                    <div class = "row">
                        <div class = "col-md-2">
                        </div>
                        <div class = "col-md-9">
                            <h2 class = "line-divider"></h2>
                        </div>
                        <div class = "col-md-1">
                        </div>
                    </div>
                    <div class = "row mb-3" style = "text-align: left;">
                        <div class = "col-md-2">
                        </div>
                        <div class = "col-xs-12 col-sm-12 col-md-4 col-xxl-2">
                            <a href="singapore-mask.html"><img src = "images/Singapore Mask.png" alt = "image of Singaporeans" height = 120px></a>
                        </div>
                        <div class ="col-xs-12 col-sm-12 col-md-5 col-xxl-7">
                            <br>
                            <h5><a class="nav-link" href = "#">No masks on public transport, free vaccines: 6 things you need to know as S'pore lifts Covid 19 rules </a></h5>
                        </div>
                        <div class = "col-md-2">
                        </div>
                    </div>
                    <div class = "row">
                        <div class = "col-md-2">
                        </div>
                        <div class = "col-md-9">
                            <h2 class = "line-divider"></h2>
                        </div>
                        <div class = "col-md-1">
                        </div>
                    </div>
                </div>
                <br>
                <br>
                <div class = "container text-left">
                    <div class = "row">
                        <div class = "col-md-1">
                        </div>
                        <div class = "col-md-4">
                            <h3>Comments:</h3>
                        </div>
                        <div class = "col-md-7">
                        </div>
                    </div>
                    <div class = "row">
                        <div class = "col-md-1">
                        </div>
                        <div class = "col-md-10">
                            <h2 class = "line-divider"></h2>
                        </div>
                        <div class = "col-md-2">
                        </div>
                    </div>
                    <div class ="row">
                        <div class = "col-md-1"></div>
                        <div class = "col-md-10">
                            <p>Enter a comment: </p>
                            <div class="input-group mb-3">
                                <span class="input-group-text" id="basic-addon1">@</span>
                                <input type="text" class="form-control" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1">
                              </div>
                            <div class="input-group">
                                <span class="input-group-text">Tell us what you think! </span>
                                <textarea class="form-control" aria-label="With textarea"></textarea>
                                <button class="btn btn-outline-secondary" type="button" id="button-addon2">Submit</button>
                            </div>
                        </div>
                        <div class = 'col-md-1'></div>
                    </div>
                    <br>
                    <div class = "row">
                        <div class = "col-md-1"></div>
                        <div class =  "col-xs-12 col-sm-12 col-md-2 col-xxl-1">
                            <img src = "images/strawberry.jpg" alt = "profile picture of user 283strawberry" height="100px">
                        </div>
                        <div class =  "col-xs-12 col-sm-12 col-md-7 col-xxl-8"> style = "text-align: left;">
                            <br>
                            <h5>@283strawberry:</h5>
                            <p> Well Written! Great Insight.</p>
                            <p> 3 days ago <a href = "#">reply</a></p> 
                        </div>
                        <div class = "col-md-2"></div>
                    </div>
                    <div class = "row">
                        <div class = "col-md-1"></div>
                        <div class =  "col-xs-12 col-sm-12 col-md-2 col-xxl-1">
                            <img src = "images/mike.jpg" alt = "profile picture of user mike32123" height="100px">
                        </div>
                        <div class =  "col-xs-12 col-sm-12 col-md-7 col-xxl-8">style = "text-align: left;">
                            <br>
                            <h5>@mike32123:</h5>
                            <p> Learnt something new today!</p>
                            <p> 2 weeks ago <a href = "#">reply</a></p> 
                        </div>
                        <div class = "col-md-1">
                        </div>
                    </div>
                    <div class = "row">
                        <div class = "col-md-1"></div>
                        <div class = "col-xs-12 col-sm-12 col-md-2 col-xxl-1">
                            <img src = "images/kathy.jpg" alt = "profile picture of user KathyBrian" height="100px">
                        </div>
                        <div class =  "col-xs-12 col-sm-12 col-md-7 col-xxl-8"> style = "text-align: left;">
                            <br>
                            <h5>@KathyBrian:</h5>
                            <p> Great article... </p>
                            <p> 1 month ago <a href = "#">reply</a></p> 
                        </div>
                        <div class = "col-md-1">
                        </div>
                    </div>

                    <br>
                    <br>
                    <!--footer-->
                    <h2 class = "line-divider"></h2>
                    <div class = "container" style = "text-align: left;">
                        <br>        
                        <div class="row">
                            <div class="col-sm-4 mb-3 mb-sm-0">
                            <div class="card">
                                <div class="card-body">
                                <h5 class="card-title">Sections</h5>
                                <p class="card-text"><a class="nav-link" href = "index.html">Top News</a></p>
                                    <p class="card-text"><a class="nav-link" href = "index.html">Latest News</a></p>
                                    <p class="card-text"><a class="nav-link" href = "world.html">World</a></p>
                                    <p class="card-text"><a class="nav-link" href = "singapore.html">Singapore</a></p>
                                    <p class="card-text"><a class="nav-link" href = "sports.html">Sports</a></p>
                                </div>
                            </div>
                            </div>
                            <div class="col-sm-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">About Daily News</h5>
                                    <p class="card-text"><a class="nav-link" href = "#">About Us</a></p>
                                    <p class="card-text"><a class="nav-link" href = "#">Contact Us</a></p>
                                    <p class="card-text"><a class="nav-link" href = "#">Feedback to Us</a></p>
                                    <p class="card-text"><a class="nav-link" href = "#">Terms and Conditions</a></p>
                                    <p class="card-text"><a class="nav-link" href = "#">Privacy Policy</a></p>
                                </div>
                            </div>
                            </div>
                            <div class="col-sm-4">
                            <div class="card">
                                <div class="card-body" <br>
        
                                    <h5 class="card-title">Follow Us On: </h5>
                                    <div class = "social">
                                        <p>
                                            <a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>
                                            <a href="https://www.instagram.com/"> <i class="fa fa-instagram"></i></a>
                                            <a href="https://plus.google.com"><i class="fa fa-google"></i></a>
                                            <a href="https://www.pinterest.com/"><i class="fa fa-pinterest-p"></i></a>
                                            <a href="https://www.reddit.com/"><i class="fa fa-reddit"></i></a>
                                            <a href="https://twitter.com/?lang=en-sg"><i class="fa fa-twitter"></i></a>
                                        </p>
                                    </div>
                                    
                                    
                                    <h5> Subscribe to our newsletter: </h5>
                                    <form class="row g-3">
                                        <div class="col-md-4">
                                          <label for="validationServer01" class="form-label">First name</label>
                                          <input type="text" class="form-control is-valid" id="validationServer01" value="Mark" required>
                                          <div class="valid-feedback">
                                            Looks good!
                                          </div>
                                        </div>
                                        <div class="col-md-4">
                                          <label for="validationServer02" class="form-label">Last name</label>
                                          <input type="text" class="form-control is-valid" id="validationServer02" value="Otto" required>
                                          <div class="valid-feedback">
                                            Looks good!
                                          </div>
                                        </div>
                                        <div class="input-group mb-3">
                                            <div class="input-group has-validation">
                                            <input type="text" class="form-control is-invalid" placeholder="Recipient's email" aria-label="Text input with dropdown button" required>
                                            <button class="btn btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">@example.com</button>
                                            <ul class="dropdown-menu dropdown-menu-end">
                                              <li><a class="dropdown-item" href="#">@gmail.com</a></li>
                                              <li><a class="dropdown-item" href="#">@yahoo.com</a></li>
                                              <li><a class="dropdown-item" href="#">@hotmail.com</a></li>
                                              <li><hr class="dropdown-divider"></li>
                                              <li><a class="dropdown-item" href="#">
                                                <p>others:</p>
                                                <div class="input-group mb-3">
                                                    <div class="input-group-text">
                                                    <input class="form-check-input mt-0" type="checkbox" value="" aria-label="Checkbox for following text input">
                                                    </div>
                                                    <input type="text" class="form-control" aria-label="Text input with checkbox">
                                                </div>
                                            </a></li>
                                            </ul>
                                            <div id="validationServerUsernameFeedback" class="invalid-feedback">
                                                Please enter a valid email.
                                            </div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-12">
                                          <div class="form-check">
                                            <input class="form-check-input is-invalid" type="checkbox" value="" id="invalidCheck3" aria-describedby="invalidCheck3Feedback" required>
                                            <label class="form-check-label" for="invalidCheck3">
                                              Agree to terms and conditions
                                            </label>
                                            <div id="invalidCheck3Feedback" class="invalid-feedback">
                                              You must agree before submitting.
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-12">
                                          <button class="btn btn-primary" type="submit">Submit form</button>
                                        </div>
                                    </form>
                                    
                                    
                                    
                                    
                                </div>
                            </div>
                            </div>
                        </div>
                        <br>
                        <p> &copy; 2023 Nicole</p>
                    </div>
            
                    
                </div>
            </div>
        </div>
        `;

        };

    };

    const div = document.getElementById('full_view_div_container');
    div.classList.add('visible')

   document.getElementById("body").style.overflow = "hidden";
};

function closeContent(){
   const div = document.getElementById('full_view_div_container');
   div.classList.remove('visible');
   document.getElementById("body").style.overflow = "visible"
};


