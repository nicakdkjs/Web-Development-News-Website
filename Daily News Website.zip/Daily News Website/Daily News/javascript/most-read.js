var mostRead = [
    {
        info: "Once home to civilisations, fabled Antioch left in ruins after Türkiye Syria earthquake",
        category: "WORLD",
        number:1,
        link: "world.html",
        content:2,
    },
    {
        info: "Sydney swelters through autumn heatwave, bushfire threat looms",
        category: "WORLD",
        number:2,
        link: "world.html",
        content:4,
    },
    {
        info: "At least 4 dead, including gunman, in shooting at Michigan State University",
        category: "WORLD",
        number:3,
        link: "world.html",
        content:3,
    },
    {
        info: "Gakpo off the mark as Liverpool down Everton 2 to 0",
        category: "SPORTS",
        number:4,
        link: "sports.html",
        content:1,
    }
  ];

  
  
var most_read_Template = Handlebars.compile(document.getElementById("most-read-template").innerHTML);

var most_read_container = document.getElementById("most_read_template");

for (var i = 0; i < mostRead.length; i++) {
    var mainHtml = most_read_Template(mostRead[i]);

    most_read_container.insertAdjacentHTML("beforeend", mainHtml);
}




