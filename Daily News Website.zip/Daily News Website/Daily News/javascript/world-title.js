var worldData = [
    {
        title: "Sydney swelters through autumn heatwave, bushfire threat looms",
        image: "images/sydney.avif",
        content:4,
        alt:"image of Sydney",
    },
    {
        title: "At least 4 dead, including gunman, in shooting at Michigan State University",
        image: "images/michigan-1.jpg",
        content:3,
        alt:"image of Spurs",
    },
    {
        title: " Once home to civilisations, fabled Antioch left in ruins after Türkiye Syria earthquake",
        image: "images/Turkiye.avif" ,
        content:2,
        alt:"image of Turkiye",
    }
  ];
  
var world_template = Handlebars.compile(document.getElementById("world-template").innerHTML);

var world_container = document.getElementById("world_template");

for (var i = 0; i < worldData.length; i++) {
    var mainHtml = world_template(worldData[i]);

    world_container.insertAdjacentHTML("beforeend", mainHtml);
}



