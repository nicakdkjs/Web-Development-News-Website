var mainData = [
    {
      Spurs: "Spurs can't afford more injuries says Conte ahead of Milan last 16 tie",
      image: "images/Spurs.avif",
      content:0,
    },
    {
        Spurs: "Spurs can't afford more injuries says Conte ahead of Milan last 16 tie",
        image: "images/Spurs.avif",
        content:0,
    },
    {
        Spurs: "Spurs can't afford more injuries says Conte ahead of Milan last 16 tie",
        image: "images/Spurs.avif",
        content:0,
    }
  ];
  
var Main_news_Template = Handlebars.compile(document.getElementById("main-template").innerHTML);

var Main_news_container = document.getElementById("main_news_template");

for (var i = 0; i < mainData.length; i++) {
    var mainHtml = Main_news_Template(mainData[i]);

    Main_news_container.insertAdjacentHTML("beforeend", mainHtml);
}


